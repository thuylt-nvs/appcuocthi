/* ==========================================================================
   NovaStars × NVS Championship — Student Pilot Verification Suite
   v0.2 Automated Test Suite for Student Mode Rules & Sandbox Isolation
   ========================================================================== */

class StudentPilotVerificationSuite {
  constructor() {
    this.results = [];
  }

  assert(condition, message) {
    if (!condition) {
      throw new Error(`STUDENT_PILOT_VERIFICATION_FAILED: ${message}`);
    }
  }

  test(name, fn) {
    try {
      fn();
      this.results.push({ name, passed: true });
      console.log(`✅ [Student Pilot Test PASSED] ${name}`);
    } catch (err) {
      this.results.push({ name, passed: false, error: err.message });
      console.log(`❌ [Student Pilot Test FAILED] ${name}: ${err.message}`);
    }
  }

  runAll() {
    console.log('\n===================================================================');
    console.log('🚀 RUNNING STUDENT PILOT VERIFICATION & ISOLATION SUITE');
    console.log('===================================================================\n');

    // 1. Presenter Control Absence in Student Mode
    this.test('1. Student Mode never renders Presenter controls', () => {
      window.DEMO_SHOWCASE = false;
      const student = new DemoStudentController();
      student.init();
      const isDemoActive = window.DEMO_SHOWCASE === true;
      this.assert(isDemoActive === false, 'Presenter panel must not activate in Student Mode');
    });

    // 2. Presenter Control Presence in Team Mode
    this.test('2. Team Mode renders Presenter controls', () => {
      window.DEMO_SHOWCASE = true;
      const showcase = new DemoShowcaseController();
      showcase.init();
      const isDemoActive = window.DEMO_SHOWCASE === true;
      this.assert(isDemoActive === true, 'Team Mode must enable DEMO_SHOWCASE flag');
    });

    // 3. Independent Sandbox State
    this.test('3. Student and Team sandbox state cannot overwrite one another', () => {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('novastars_demo_showcase_v1', JSON.stringify({ team: 'val' }));
        sessionStorage.setItem('novastars_student_pilot_v1', JSON.stringify({ student: 'val' }));

        const student = new DemoStudentController();
        student.init();
        student.startPilot('GRADE_4_5');

        const teamVal = JSON.parse(sessionStorage.getItem('novastars_demo_showcase_v1'));
        this.assert(teamVal.team === 'val', 'Team sandbox state was overwritten by Student Mode');
      }
    });

    // 4. Production Storage Isolation
    this.test('4. Production LocalStorage remains byte-for-byte unchanged', () => {
      const prodKeys = ['novastars_player_state_v1', 'novastars_user_settings', 'novastars_app_cache'];
      const initialSnapshots = {};

      if (typeof localStorage !== 'undefined') {
        prodKeys.forEach(k => {
          localStorage.setItem(k, JSON.stringify({ key: k, value: `prod_val_${k}` }));
          initialSnapshots[k] = localStorage.getItem(k);
        });
      }

      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_1_3');
      for (let i = 0; i < 5; i++) {
        student.answerExamQuestion(`g13_e${i+1}`, 0);
      }
      for (let i = 0; i < 3; i++) {
        student.answerBoostQuestion(`sb_${i+1}`, 0);
        student.advanceBoostQuestion();
      }

      if (typeof localStorage !== 'undefined') {
        prodKeys.forEach(k => {
          const afterVal = localStorage.getItem(k);
          this.assert(afterVal === initialSnapshots[k], `Production key ${k} was mutated during Student Pilot execution!`);
        });
      }
    });

    // 5 & 6. Age Group Question Pools
    this.test('5 & 6. Grade 1–3 and Grade 4–5 receive correct 5-question short pools', () => {
      const student = new DemoStudentController();
      const poolG13 = student.examQuestions['GRADE_1_3'];
      const poolG45 = student.examQuestions['GRADE_4_5'];

      this.assert(poolG13.length === 5, 'Grade 1–3 exam pool must have 5 questions');
      this.assert(poolG45.length === 5, 'Grade 4–5 exam pool must have 5 questions');
    });

    // 7. Short Exam Completion
    this.test('7. Short Exam completes after exactly 5 questions', () => {
      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_4_5');
      student.currentStepIndex = 3; // Exam Question view

      const pool = student.examQuestions['GRADE_4_5'];
      for (let i = 0; i < 4; i++) {
        student.answerExamQuestion(pool[i].id, 0);
        this.assert(student.currentStepIndex === 3, 'Must remain on exam question view until final answer');
      }
      student.answerExamQuestion(pool[4].id, 0);
      this.assert(student.currentStepIndex === 4, 'Must transition to Practice Result (step 4) after 5th answer');
    });

    // 8. Skill Boost Completion
    this.test('8. Skill Boost completes after exactly 3 questions', () => {
      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_4_5');
      student.currentStepIndex = 5; // Boost step

      for (let i = 0; i < 3; i++) {
        student.answerBoostQuestion(`sb_${i+1}`, 0);
        student.advanceBoostQuestion();
      }
      this.assert(student.currentStepIndex === 6, 'Must transition to Reward view (step 6) after 3rd boost question');
    });

    // 9. Feedback Persistence & Restart
    this.test('9. Student feedback persists & Restart resets Student sandbox deterministically', () => {
      const student = new DemoStudentController();
      student.init();
      student.setFeedbackRating(4);
      student.setFavoritePart('Coach Nova');
      this.assert(student.pilotState.feedback.q1 === 4, 'Feedback rating must persist');
      this.assert(student.pilotState.feedback.q2 === 'Coach Nova', 'Favorite part must persist');

      student.restartPilot();
      this.assert(student.currentStepIndex === 0, 'Restart must reset step index to 0');
      this.assert(student.pilotState.feedback.q1 === 5, 'Restart must reset feedback to default');
    });

    // 10. No PII Field
    this.test('10. No PII field exists in Student pilot state', () => {
      const student = new DemoStudentController();
      const keys = Object.keys(student.pilotState);
      const piiFields = ['name', 'fullName', 'school', 'email', 'phone', 'dob'];
      piiFields.forEach(f => {
        this.assert(!keys.includes(f), `PII field ${f} must not exist in Student pilot state`);
      });
    });

    const passed = this.results.filter(r => r.passed).length;
    const total = this.results.length;

    console.log('\n===================================================================');
    console.log(`📊 STUDENT PILOT VERIFICATION RESULTS: ${passed}/${total} PASSED`);
    console.log('===================================================================\n');

    return { total, passed, failed: total - passed, results: this.results };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { StudentPilotVerificationSuite };
} else if (typeof window !== 'undefined') {
  window.StudentPilotVerificationSuite = StudentPilotVerificationSuite;
}
