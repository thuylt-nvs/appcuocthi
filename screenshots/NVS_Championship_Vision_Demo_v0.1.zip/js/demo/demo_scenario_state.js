/* ==========================================================================
   NovaStars × NVS Championship — Demo Scenario State Generator
   v0.1 Isolated Presentation Presets (Domain-Consistent)
   ========================================================================== */

const DemoScenarioState = {

  // Seeded Student Profiles
  profiles: {
    GRADE_2: {
      id: 'demo_student_g2',
      name: 'Bé Su',
      grade: 2,
      avatar: '👧',
      ageGroupName: 'Khối 1–3'
    },
    GRADE_5: {
      id: 'demo_student_g5',
      name: 'Minh Trí',
      grade: 5,
      avatar: '👦',
      ageGroupName: 'Khối 4–5'
    }
  },

  // Seeded Account Tiers
  accountTiers: {
    FREE: {
      isPremium: false,
      tierName: 'Miễn Phí',
      explanationAccess: 'LOCKED'
    },
    PREMIUM: {
      isPremium: true,
      tierName: 'Premium Preview',
      explanationAccess: 'UNLOCKED'
    }
  },

  // Scenario Presets: Before Exam, After Exam, After Skill Boost, Preparing for Round 1, Future Finalist
  scenarios: {
    NEW_STUDENT: {
      id: 'NEW_STUDENT',
      name: 'Học Sinh Mới Khoái Phiêu Lưu',
      xp: 0,
      stars: 0,
      streak: 1,
      rankEligibleXP: 0,
      hasExamToday: false,
      examScore: null,
      boostCompleted: false,
      missions: { examCompleted: false, boostCompleted: false, rewardClaimed: false },
      championshipStage: 'ROUND_1_QUALIFYING',
      recommendedAction: 'Làm bài thi thử 20 phút hôm nay để nhận nhận diện điểm mạnh!'
    },
    BEFORE_EXAM: {
      id: 'BEFORE_EXAM',
      name: 'Trước Bài Thi Thử Hôm Nay',
      xp: 120,
      stars: 15,
      streak: 3,
      rankEligibleXP: 80,
      hasExamToday: false,
      examScore: null,
      boostCompleted: false,
      missions: { examCompleted: false, boostCompleted: false, rewardClaimed: false },
      championshipStage: 'ROUND_1_QUALIFYING',
      recommendedAction: 'Bắt đầu bài thi thử hôm nay (Khối 4–5 / 20 câu / 20 phút)'
    },
    AFTER_EXAM: {
      id: 'AFTER_EXAM',
      name: 'Sau Khi Thi Thử (Cần Rèn Luyện)',
      xp: 170,
      stars: 15,
      streak: 3,
      rankEligibleXP: 130,
      hasExamToday: true,
      examScore: { score: 75, correct: 15, total: 20, timeSpentMinutes: 14 },
      boostCompleted: false,
      missions: { examCompleted: true, boostCompleted: false, rewardClaimed: false },
      championshipStage: 'ROUND_1_QUALIFYING',
      recommendedAction: 'Coach Nova đề xuất: Rèn luyện NL4 Tư Duy Giải Quyết Vấn Đề (+6 XP / câu)'
    },
    AFTER_SKILL_BOOST: {
      id: 'AFTER_SKILL_BOOST',
      name: 'Sau Khi Bứt Phá Skill Boost',
      xp: 200,
      stars: 25,
      streak: 3,
      rankEligibleXP: 130,
      hasExamToday: true,
      examScore: { score: 75, correct: 15, total: 20, timeSpentMinutes: 14 },
      boostCompleted: true,
      missions: { examCompleted: true, boostCompleted: true, rewardClaimed: true },
      championshipStage: 'ROUND_1_QUALIFYING',
      recommendedAction: 'Hoàn thành bứt phá NL4! Hãy tiếp tục duy trì chuỗi học hằng ngày.'
    },
    PREPARING_ROUND_1: {
      id: 'PREPARING_ROUND_1',
      name: 'Chuẩn Bị Vòng 1 Sắp Tới',
      xp: 350,
      stars: 45,
      streak: 7,
      rankEligibleXP: 260,
      hasExamToday: true,
      examScore: { score: 85, correct: 17, total: 20, timeSpentMinutes: 12 },
      boostCompleted: true,
      missions: { examCompleted: true, boostCompleted: true, rewardClaimed: true },
      championshipStage: 'ROUND_1_QUALIFYING',
      recommendedAction: 'Bảo vệ vị trí Top 10 Vòng Thi Tuần (Còn 3 ngày mở thưởng)'
    },
    FUTURE_FINALIST: {
      id: 'FUTURE_FINALIST',
      name: 'Ứng Viên Vòng Chung Kết Vùng',
      xp: 850,
      stars: 120,
      streak: 21,
      rankEligibleXP: 720,
      hasExamToday: true,
      examScore: { score: 95, correct: 19, total: 20, timeSpentMinutes: 10 },
      boostCompleted: true,
      missions: { examCompleted: true, boostCompleted: true, rewardClaimed: true },
      championshipStage: 'NATIONAL_FINAL',
      recommendedAction: 'Sẵn sàng tranh tài Vòng Chung kết Toàn quốc NVS 🏆'
    }
  },

  /**
   * Generates a clean, domain-consistent presentation state
   */
  createState(gradeKey = 'GRADE_5', tierKey = 'FREE', scenarioKey = 'BEFORE_EXAM') {
    const student = this.profiles[gradeKey] || this.profiles.GRADE_5;
    const tier = this.accountTiers[tierKey] || this.accountTiers.FREE;
    const scenario = this.scenarios[scenarioKey] || this.scenarios.BEFORE_EXAM;

    return {
      user: {
        id: student.id,
        name: student.name,
        grade: student.grade,
        avatar: student.avatar,
        ageGroupName: student.ageGroupName
      },
      account: {
        isPremium: tier.isPremium,
        tierName: tier.tierName,
        explanationAccess: tier.explanationAccess
      },
      scenario: {
        id: scenario.id,
        name: scenario.name,
        championshipStage: scenario.championshipStage,
        recommendedAction: scenario.recommendedAction
      },
      xp: scenario.xp,
      stars: scenario.stars,
      streak: scenario.streak,
      rankEligibleXP: scenario.rankEligibleXP,
      dailyMissions: [
        { id: 'm1', title: 'Hoàn thành 1 bài thi thử ngày', progress: scenario.missions.examCompleted ? 1 : 0, max: 1, rewardXp: 20, completed: scenario.missions.examCompleted },
        { id: 'm2', title: 'Luyện 5 câu Skill Boost', progress: scenario.missions.boostCompleted ? 5 : (scenario.hasExamToday ? 2 : 0), max: 5, rewardXp: 15, completed: scenario.missions.boostCompleted },
        { id: 'm3', title: 'Đạt chuỗi học 3 ngày', progress: Math.min(scenario.streak, 3), max: 3, rewardXp: 10, completed: scenario.streak >= 3 }
      ],
      competencySignals: [
        { code: 'NL1', name: 'Năng lực Số & Dữ liệu', icon: '🔢', count: 18, accuracyPercent: 88, status: 'Mạnh' },
        { code: 'NL2', name: 'Năng lực Ngôn ngữ & Truyền thông', icon: '🗣️', count: 14, accuracyPercent: 82, status: 'Khá' },
        { code: 'NL3', name: 'Năng lực Khoa học & Tự nhiên', icon: '🧪', count: 12, accuracyPercent: 75, status: 'Khá' },
        { code: 'NL4', name: 'Năng lực Tư duy Giải quyết Vấn đề', icon: '🧩', count: 25, accuracyPercent: 64, status: 'Cần Rèn Luyện 🚀' },
        { code: 'NL5', name: 'Năng lực Sáng tạo & Thiết kế', icon: '🎨', count: 10, accuracyPercent: 80, status: 'Khá' },
        { code: 'NL6', name: 'Năng lực Thích ứng & Tự chủ', icon: '🛡️', count: 8, accuracyPercent: 90, status: 'Xuất sắc' },
        { code: 'NL7', name: 'Năng lực Hợp tác & Toàn cầu', icon: '🌐', count: 6, accuracyPercent: 85, status: 'Khá' }
      ]
    };
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DemoScenarioState };
} else if (typeof window !== 'undefined') {
  window.DemoScenarioState = DemoScenarioState;
}
