/* ==========================================================================
   NovaStars × NVS Championship — Vision Demo App Bootstrapper
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  window.DEMO_SHOWCASE = true;
  const showcaseController = new DemoShowcaseController();
  showcaseController.init();

  const urlParams = new URLSearchParams(window.location.search);
  const targetScreen = urlParams.get('screen') || urlParams.get('step');
  if (targetScreen) {
    showcaseController.jumpToScreen(targetScreen);
  }
});
