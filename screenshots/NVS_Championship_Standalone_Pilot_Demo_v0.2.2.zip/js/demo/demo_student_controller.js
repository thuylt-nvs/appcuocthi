/* ==========================================================================
   NovaStars × NVS Championship — Demo Student Controller
   v0.2.2 Hardened Student Pilot Orchestrator & State Manager
   ========================================================================== */

class DemoStudentController {
  constructor() {
    this.storageKey = 'novastars_student_pilot_v1';
    this.currentStepIndex = 0; // 0: Welcome, 1: Home, 2: Champ Home, 3: Exam, 4: Result, 5: Boost, 6: Reward, 7: Journey, 8: Feedback, 9: Thank You
    this.currentExamIdx = 0;
    this.currentBoostIdx = 0;
    this.telemetryRepo = typeof PilotTelemetryRepository !== 'undefined' ? new PilotTelemetryRepository() : null;

    // Anonymous Session State (Zero PII, State Persisted & Restored)
    this.pilotState = {
      sessionId: 'pilot_' + Math.random().toString(36).substring(2, 9),
      ageGroup: 'GRADE_4_5',
      currentStepIndex: 0,
      currentExamIdx: 0,
      currentBoostIdx: 0,
      xp: 0,
      stars: 0,
      streak: 1,
      examAnswers: {},
      examScore: null,
      boostAnswers: {},
      boostCorrectCount: 0,
      boostXpEarned: 0,
      boostCompleted: false,
      feedback: { q1: 5, q2: 'Coach Nova', q3: 'Có!', suggestion: '' },
      loggedEvents: {}
    };

    // Public Pilot Fixture References (No Production Data Imports)
    this.examQuestions = {
      GRADE_1_3: typeof PILOT_EXAM_G13 !== 'undefined' ? PILOT_EXAM_G13 : [],
      GRADE_4_5: typeof PILOT_EXAM_G45 !== 'undefined' ? PILOT_EXAM_G45 : []
    };

    this.boostQuestions = typeof PILOT_SKILL_BOOST !== 'undefined' ? PILOT_SKILL_BOOST : [];
    this.boostFeedback = null;
  }

  /**
   * Hard Item Safety Guard: Ensures no SECURE_ACTIVE or unapproved items load in Student Mode
   */
  assertPilotItemSafety(item) {
    if (!item) return;
    const allowed = ['DEMO_PILOT_ONLY', 'READY_FOR_PILOT'];
    const status = item.contentStatus || item.status;
    if (!allowed.includes(status)) {
      throw new Error(`PILOT_ITEM_SAFETY_VIOLATION: Item ${item.itemId || item.id} has unapproved status '${status}'. SECURE_ACTIVE items are forbidden in Student Mode.`);
    }
  }

  init() {
    this.loadFromStorage();
    window.studentController = this;
    window.DEMO_SHOWCASE = false;
    this.renderCurrentStep();
    console.log('🚀 [StudentPilot] Student Controller initialized successfully.');
  }

  loadFromStorage() {
    try {
      if (typeof sessionStorage !== 'undefined') {
        const raw = sessionStorage.getItem(this.storageKey);
        if (raw) {
          const parsed = JSON.parse(raw);
          this.pilotState = { ...this.pilotState, ...parsed };
          this.currentStepIndex = this.pilotState.currentStepIndex ?? 0;
          this.currentExamIdx = this.pilotState.currentExamIdx ?? 0;
          this.currentBoostIdx = this.pilotState.currentBoostIdx ?? 0;
        }
      }
    } catch (e) {
      console.warn('Could not read student pilot storage:', e);
    }
  }

  saveToStorage() {
    try {
      if (typeof sessionStorage !== 'undefined') {
        this.pilotState.currentStepIndex = this.currentStepIndex;
        this.pilotState.currentExamIdx = this.currentExamIdx;
        this.pilotState.currentBoostIdx = this.currentBoostIdx;
        sessionStorage.setItem(this.storageKey, JSON.stringify(this.pilotState));
      }
    } catch (e) {
      console.warn('Could not write student pilot storage:', e);
    }
  }

  /**
   * Log business event exactly once per session key to prevent duplicates on reload
   */
  logOnce(eventKey, eventName, payload = {}) {
    if (!this.pilotState.loggedEvents) {
      this.pilotState.loggedEvents = {};
    }
    if (this.pilotState.loggedEvents[eventKey]) {
      return; // Already logged
    }
    this.pilotState.loggedEvents[eventKey] = true;

    const evt = {
      eventId: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : 'evt_' + Math.random().toString(36).substring(2, 9),
      event: eventName,
      sessionId: this.pilotState.sessionId,
      ageGroup: this.pilotState.ageGroup,
      timestamp: new Date().toISOString(),
      ...payload
    };

    if (this.telemetryRepo) {
      this.telemetryRepo.logEvent(evt);
    }
    this.saveToStorage();
  }

  startPilot(ageGroupKey) {
    this.pilotState.ageGroup = ageGroupKey;
    this.currentExamIdx = 0;
    this.currentBoostIdx = 0;
    this.pilotState.currentExamIdx = 0;
    this.pilotState.currentBoostIdx = 0;
    this.pilotState.examAnswers = {};
    this.pilotState.examScore = null;
    this.pilotState.boostAnswers = {};
    this.pilotState.boostCorrectCount = 0;
    this.pilotState.boostXpEarned = 0;
    this.pilotState.boostCompleted = false;

    this.logOnce('pilot_started', 'pilot_started', { ageGroupKey });
    this.currentStepIndex = 1; // S1 Home
    this.saveToStorage();
    this.renderCurrentStep();
  }

  nextStep() {
    if (this.currentStepIndex < 9) {
      this.currentStepIndex++;
      this.handleStepTransition();
      this.saveToStorage();
      this.renderCurrentStep();
    }
  }

  prevStep() {
    if (this.currentStepIndex > 1) {
      this.currentStepIndex--;
      this.handleStepTransition();
      this.saveToStorage();
      this.renderCurrentStep();
    }
  }

  handleStepTransition() {
    const stepNames = ['welcome', 'home', 'champ_home', 'exam_question', 'practice_result', 'skill_boost', 'reward', 'journey', 'feedback', 'thank_you'];
    const screenName = stepNames[this.currentStepIndex] || 'unknown';
    this.logOnce(`screen_${this.currentStepIndex}`, 'screen_viewed', { screenName, stepIndex: this.currentStepIndex });

    if (this.currentStepIndex === 2) {
      this.logOnce('championship_opened', 'championship_opened');
    } else if (this.currentStepIndex === 3) {
      this.logOnce('short_exam_started', 'short_exam_started');
    } else if (this.currentStepIndex === 4) {
      this.logOnce('practice_result_seen', 'practice_result_seen');
    } else if (this.currentStepIndex === 5) {
      this.logOnce('skill_boost_started', 'skill_boost_started');
    } else if (this.currentStepIndex === 7) {
      this.logOnce('journey_seen', 'journey_seen');
    }
  }

  answerExamQuestion(questionId, optionIdx) {
    const pool = this.examQuestions[this.pilotState.ageGroup] || this.examQuestions.GRADE_4_5;
    const curQ = pool[this.currentExamIdx] || pool[0];
    if (!curQ) return;
    this.assertPilotItemSafety(curQ);

    // P1 Assert Question/State Match
    const curId = curQ.itemId || curQ.id;
    if (questionId !== curId) {
      throw new Error(`QUESTION_STATE_MISMATCH: Passed questionId '${questionId}' does not match currentQuestion '${curId}'`);
    }

    this.pilotState.examAnswers[curId] = optionIdx;

    if (this.currentExamIdx < pool.length - 1) {
      this.currentExamIdx++;
      this.pilotState.currentExamIdx = this.currentExamIdx;
      this.saveToStorage();
      this.renderCurrentStep();
    } else {
      // Complete Short Exam
      let correct = 0;
      pool.forEach(item => {
        this.assertPilotItemSafety(item);
        const qId = item.itemId || item.id;
        if (this.pilotState.examAnswers[qId] === item.correctAnswer) correct++;
      });
      this.pilotState.examScore = {
        score: Math.round((correct / pool.length) * 100),
        correctCount: correct,
        totalCount: pool.length
      };
      this.logOnce('short_exam_completed', 'short_exam_completed', this.pilotState.examScore);
      this.currentStepIndex = 4; // S4 Practice Result
      this.saveToStorage();
      this.renderCurrentStep();
    }
  }

  answerBoostQuestion(questionId, optionIdx) {
    const q = this.boostQuestions[this.currentBoostIdx];
    if (!q) return;
    this.assertPilotItemSafety(q);

    // P1 Assert Question/State Match
    const curId = q.itemId || q.id;
    if (questionId !== curId) {
      throw new Error(`QUESTION_STATE_MISMATCH: Passed questionId '${questionId}' does not match currentQuestion '${curId}'`);
    }

    this.pilotState.boostAnswers[curId] = optionIdx;
    const isCorrect = optionIdx === q.correctAnswer;
    this.boostFeedback = { isCorrect };
    this.saveToStorage();
    this.renderCurrentStep();
  }

  advanceBoostQuestion() {
    this.boostFeedback = null;
    if (this.currentBoostIdx < this.boostQuestions.length - 1) {
      this.currentBoostIdx++;
      this.pilotState.currentBoostIdx = this.currentBoostIdx;
      this.saveToStorage();
      this.renderCurrentStep();
    } else {
      // Skill Boost Complete: Idempotent Reward Calculation from final saved answers
      if (!this.pilotState.boostCompleted) {
        let correctCount = 0;
        this.boostQuestions.forEach(item => {
          this.assertPilotItemSafety(item);
          const qId = item.itemId || item.id;
          if (this.pilotState.boostAnswers[qId] === item.correctAnswer) correctCount++;
        });

        const earnedXP = correctCount * 6; // Max 18 XP
        this.pilotState.boostCorrectCount = correctCount;
        this.pilotState.boostXpEarned = earnedXP;
        this.pilotState.xp = (this.pilotState.xp ?? 0) + earnedXP;
        this.pilotState.stars = (this.pilotState.stars ?? 0) + 10;
        this.pilotState.boostCompleted = true;

        this.logOnce('skill_boost_completed', 'skill_boost_completed', { correctCount, xpEarned: earnedXP, starsEarned: 10 });
      }

      this.currentStepIndex = 6; // S6 Reward
      this.saveToStorage();
      this.renderCurrentStep();
    }
  }

  setFeedbackRating(val) {
    this.pilotState.feedback.q1 = val;
    this.saveToStorage();
    this.renderCurrentStep();
  }

  setFavoritePart(partStr) {
    this.pilotState.feedback.q2 = partStr;
    this.saveToStorage();
    this.renderCurrentStep();
  }

  setReturnIntent(intentStr) {
    this.pilotState.feedback.q3 = intentStr;
    this.saveToStorage();
    this.renderCurrentStep();
  }

  setSuggestion(textStr) {
    this.pilotState.feedback.suggestion = (textStr || '').substring(0, 200);
    this.saveToStorage();
  }

  submitFeedback() {
    this.logOnce('feedback_submitted', 'feedback_submitted', this.pilotState.feedback);
    this.logOnce('pilot_completed', 'pilot_completed', { sessionId: this.pilotState.sessionId });
    this.currentStepIndex = 9; // S9 Thank You
    this.saveToStorage();
    this.renderCurrentStep();
  }

  restartPilot() {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem(this.storageKey);
    }
    this.pilotState = {
      sessionId: 'pilot_' + Math.random().toString(36).substring(2, 9),
      ageGroup: 'GRADE_4_5',
      currentStepIndex: 0,
      currentExamIdx: 0,
      currentBoostIdx: 0,
      xp: 0,
      stars: 0,
      streak: 1,
      examAnswers: {},
      examScore: null,
      boostAnswers: {},
      boostCorrectCount: 0,
      boostXpEarned: 0,
      boostCompleted: false,
      feedback: { q1: 5, q2: 'Coach Nova', q3: 'Có!', suggestion: '' },
      loggedEvents: {}
    };
    this.currentStepIndex = 0;
    this.currentExamIdx = 0;
    this.currentBoostIdx = 0;
    this.boostFeedback = null;
    this.renderCurrentStep();
  }

  renderCurrentStep() {
    const container = document.getElementById('app-view-container');
    if (!container) return;

    window.DEMO_SHOWCASE = false;
    let html = '';

    switch (this.currentStepIndex) {
      case 0:
        html = DemoStudentViews.renderWelcome();
        break;

      case 1:
        html = DemoStudentViews.renderHome(this.pilotState);
        break;

      case 2:
        html = DemoStudentViews.renderChampionshipHome();
        break;

      case 3:
        const pool = this.examQuestions[this.pilotState.ageGroup] || this.examQuestions.GRADE_4_5;
        const curQ = pool[this.currentExamIdx] || pool[0];
        this.assertPilotItemSafety(curQ);
        html = DemoStudentViews.renderExamQuestion(curQ, this.currentExamIdx, pool.length);
        break;

      case 4:
        html = DemoStudentViews.renderPracticeResult(this.pilotState.examScore || { score: 80, correctCount: 4, totalCount: 5 });
        break;

      case 5:
        const boostQ = this.boostQuestions[this.currentBoostIdx];
        this.assertPilotItemSafety(boostQ);
        html = DemoStudentViews.renderSkillBoostQuestion(boostQ, this.currentBoostIdx, this.boostQuestions.length, this.boostFeedback);
        break;

      case 6:
        html = DemoStudentViews.renderRewardMoment(this.pilotState);
        break;

      case 7:
        html = DemoStudentViews.renderStudentJourney();
        break;

      case 8:
        html = DemoStudentViews.renderStudentFeedback(this.pilotState.feedback);
        break;

      case 9:
        html = DemoStudentViews.renderThankYou();
        break;

      default:
        html = DemoStudentViews.renderWelcome();
    }

    container.innerHTML = html;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DemoStudentController };
} else if (typeof window !== 'undefined') {
  window.DemoStudentController = DemoStudentController;
}
