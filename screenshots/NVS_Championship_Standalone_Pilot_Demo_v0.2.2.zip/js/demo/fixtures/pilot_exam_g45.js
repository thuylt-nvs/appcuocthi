/* ==========================================================================
   NovaStars × NVS Championship — Public Student Pilot Fixture: Grade 4–5 Exam
   v0.2.2 Hardened Public Pilot Item Fixtures (Canonical NL1–NL7 Mapped)
   ========================================================================== */

const PILOT_EXAM_G45 = [
  {
    itemId: 'pilot_g45_e1',
    ageGroup: 'GRADE_4_5',
    primaryCompetencyId: 'NL6',
    linkedCompetencyIds: ['NL4'],
    skillId: 'SKILL_G45_TEAM_ACTION',
    skillLabel: 'Lập kế hoạch & Tổ chức công việc nhóm',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá kỹ năng lập kế hoạch và phân công nhiệm vụ nhóm rõ ràng.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Để chuẩn bị cho bài thuyết trình nhóm dự án xanh, bước đầu tiên quan trọng nhất là gì?',
    options: [
      'A. Thảo luận mục tiêu chung và phân công nhiệm vụ phù hợp với năng lực từng bạn',
      'B. Tranh cãi chọn màu trang tríSlide trước',
      'C. Giao toàn bộ công việc cho một bạn làm hết',
      'D. Trì hoãn chờ đến gần sát hạn mới làm'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g45_e2',
    ageGroup: 'GRADE_4_5',
    primaryCompetencyId: 'NL4',
    linkedCompetencyIds: ['NL3'],
    skillId: 'SKILL_G45_PERSUASION_CONFLICT',
    skillLabel: 'Giao tiếp, truyền cảm hứng & Giải quyết bất đồng',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá kỹ năng giao tiếp thuyết phục và giữ gìn quan hệ tích cực khi bất đồng.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Trong buổi làm việc nhóm, một bạn đưa ra ý tưởng mà em không đồng ý. Em nên phản hồi thế nào?',
    options: [
      'A. "Tớ hiểu góc nhìn của bạn. Tớ có một ý khác, mình cùng so sánh hai cách nhé?"',
      'B. "Ý của bạn dở tệ, không dùng được đâu."',
      'C. Im lặng tức giận bỏ về nhà',
      'D. Nói xấu bạn với các thành viên khác'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g45_e3',
    ageGroup: 'GRADE_4_5',
    primaryCompetencyId: 'NL7',
    linkedCompetencyIds: ['NL2'],
    skillId: 'SKILL_G45_DATA_AI_LITERACY',
    skillLabel: 'Kĩ năng công nghệ, dữ liệu & AI',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá năng lực sử dụng thông tin số liệu khách quan khi làm báo cáo khoa học.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Khi thu thập dữ liệu khảo sát trực tuyến cho dự án, cách trình bày nào thể hiện tính chính xác cao nhất?',
    options: [
      'A. "Có 85% học sinh hưởng ứng chiến dịch tiết kiệm điện"',
      'B. "Rất nhiều bạn thích chiến dịch này"',
      'C. "Hầu như ai cũng thích"',
      'D. "Tự đoán số liệu không cần khảo sát"'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g45_e4',
    ageGroup: 'GRADE_4_5',
    primaryCompetencyId: 'NL5',
    linkedCompetencyIds: ['NL1'],
    skillId: 'SKILL_G45_GLOBAL_CITIZEN',
    skillLabel: 'Tinh thần công dân toàn cầu & Trách nhiệm xã hội',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá hành động tích cực vì sự phát triển bền vững và tiết kiệm tài nguyên.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Hành động nào thể hiện tinh thần công dân có trách nhiệm với môi trường sống hằng ngày?',
    options: [
      'A. Chủ động tắt thiết bị điện khi ra khỏi phòng và phân loại rác tái chế',
      'B. Mở quạt cả ngày dù không có ai trong phòng',
      'C. Xả nước lãng phí khi rửa tay',
      'D. Sử dụng nhựa dùng một lần liên tục'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g45_e5',
    ageGroup: 'GRADE_4_5',
    primaryCompetencyId: 'NL6',
    linkedCompetencyIds: ['NL2'],
    skillId: 'SKILL_G45_ADAPTABILITY_TIME',
    skillLabel: 'Hành động, thích ứng & Quản lý thời gian',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá khả năng làm chủ bản thân và thích ứng khi gặp áp lực thời gian.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Nếu thời gian làm bài còn 5 phút và còn 2 câu hỏi chưa làm, em nên xử lý thế nào?',
    options: [
      'A. Bình tĩnh rà soát và ưu tiên giải quyết câu hỏi em có khả năng làm đúng cao nhất',
      'B. Hoảng loạn đánh bừa không suy nghĩ',
      'C. Bỏ bài ngồi chơi',
      'D. Nộp bài ngay lập tức'
    ],
    correctAnswer: 0
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PILOT_EXAM_G45 };
} else if (typeof window !== 'undefined') {
  window.PILOT_EXAM_G45 = PILOT_EXAM_G45;
}
