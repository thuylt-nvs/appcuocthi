/* ==========================================================================
   NovaStars × NVS Championship — Public Student Pilot Fixture: Grade 1–3 Exam
   v0.2.2 Hardened Public Pilot Item Fixtures (Canonical NL1–NL7 Mapped)
   ========================================================================== */

const PILOT_EXAM_G13 = [
  {
    itemId: 'pilot_g13_e1',
    ageGroup: 'GRADE_1_3',
    primaryCompetencyId: 'NL6',
    linkedCompetencyIds: ['NL3'],
    skillId: 'SKILL_G13_SELF_INITIATIVE',
    skillLabel: 'Hành động & Tự giác cá nhân',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá tinh thần chủ động tự giác khi chuẩn bị góc học tập cá nhân.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Khi chuẩn bị góc học tập buổi tối ở nhà, em nên làm gì để học tập hiệu quả?',
    options: [
      'A. Chủ động dọn dẹp bàn học sạch sẽ và chuẩn bị sách vở',
      'B. Đợi bố mẹ nhắc nhở nhiều lần mới chịu ngồi vào bàn',
      'C. Vừa xem tivi vừa làm bài tập',
      'D. Để sách vở bừa bãi và ngồi chơi game'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g13_e2',
    ageGroup: 'GRADE_1_3',
    primaryCompetencyId: 'NL3',
    linkedCompetencyIds: ['NL4'],
    skillId: 'SKILL_G13_EMPATHY_FRIENDSHIP',
    skillLabel: 'Trí tuệ cảm xúc & Kết nối bạn bè',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá khả năng đồng cảm và chia sẻ cảm xúc với bạn học.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Khi thấy một bạn trong lớp đang buồn vì bị mất hộp bút, em nên làm gì?',
    options: [
      'A. Đến lắng nghe, hỏi thăm và cùng bạn tìm hộp bút',
      'B. Đứng cười và trêu chọc bạn',
      'C. Giành hộp bút của bạn khác cho bạn',
      'D. Bỏ đi chỗ khác không quan tâm'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g13_e3',
    ageGroup: 'GRADE_1_3',
    primaryCompetencyId: 'NL5',
    linkedCompetencyIds: ['NL1'],
    skillId: 'SKILL_G13_CITIZENSHIP_ENV',
    skillLabel: 'Trách nhiệm cộng đồng & Môi trường',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá ý thức bảo vệ môi trường trường học hằng ngày.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Khi thấy rác rơi trên sân trường sau giờ ra chơi, hành động tích cực nhất là gì?',
    options: [
      'A. Nhặt bỏ vào thùng rác phân loại đúng quy định',
      'B. Bỏ đi chỗ khác xem như không thấy',
      'C. Đá rác sang chỗ bạn khác',
      'D. Đổ thêm rác ra sân'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g13_e4',
    ageGroup: 'GRADE_1_3',
    primaryCompetencyId: 'NL4',
    linkedCompetencyIds: ['NL3'],
    skillId: 'SKILL_G13_COMMUNICATION_RESPECT',
    skillLabel: 'Giao tiếp & Tôn trọng góc nhìn',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá kỹ năng giao tiếp và tôn trọng ý kiến khác biệt khi thảo luận nhóm.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Khi bạn trong nhóm đưa ra ý kiến khác với em, em nên phản hồi thế nào?',
    options: [
      'A. Tôn trọng lắng nghe bạn nói hết rồi lắng nhẹ nhàng trao đổi',
      'B. Ngắt lời và quát bạn',
      'C. Cãi nhau để bắt bạn nghe theo mình',
      'D. Tức giận khóc lóc'
    ],
    correctAnswer: 0
  },
  {
    itemId: 'pilot_g13_e5',
    ageGroup: 'GRADE_1_3',
    primaryCompetencyId: 'NL2',
    linkedCompetencyIds: ['NL7'],
    skillId: 'SKILL_G13_LIFELONG_LEARNING',
    skillLabel: 'Tư duy học tập suốt đời & Phản xạ',
    indicatorId: null,
    mappingStatus: 'DEMO_MAPPED',
    contentStatus: 'DEMO_PILOT_ONLY',
    eligibleForOfficialScoring: false,
    scoringRationale: 'Đánh giá khả năng tìm kiếm quy luật và tư duy học tập chủ động.',
    reviewStatus: 'PENDING_ACADEMIC_REVIEW',
    reviewer: null,
    stem: 'Dãy thói quen học tập tốt theo thứ tự: Đọc bài -> Suy nghĩ -> Làm thử -> ... Bước tiếp theo là gì?',
    options: [
      'A. Rút kinh nghiệm và cải tiến',
      'B. Bỏ dở không làm nữa',
      'C. Chép bài người khác',
      'D. Đổ lỗi cho bạn'
    ],
    correctAnswer: 0
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PILOT_EXAM_G13 };
} else if (typeof window !== 'undefined') {
  window.PILOT_EXAM_G13 = PILOT_EXAM_G13;
}
