/* ==========================================================================
   NovaStars × NVS Championship — Demo Student Controller
   v0.2.1 Student Pilot Mode Orchestrator & Safety Guard Manager
   ========================================================================== */

class DemoStudentController {
  constructor() {
    this.storageKey = 'novastars_student_pilot_v1';
    this.currentStepIndex = 0; // 0: Welcome, 1: Home, 2: Champ Home, 3: Exam, 4: Result, 5: Boost, 6: Reward, 7: Journey, 8: Feedback, 9: Thank You
    this.telemetryRepo = typeof PilotTelemetryRepository !== 'undefined' ? new PilotTelemetryRepository() : null;

    // Anonymous Session State (Zero PII)
    this.pilotState = {
      sessionId: 'pilot_' + Math.random().toString(36).substring(2, 9),
      ageGroup: 'GRADE_4_5',
      xp: 0,
      stars: 0,
      streak: 1,
      examAnswers: {},
      examScore: null,
      boostAnswers: {},
      boostCorrectCount: 0,
      boostXpEarned: 0,
      feedback: { q1: 5, q2: 'Coach Nova', q3: 'Có!', suggestion: '' },
      events: []
    };

    // 8-Item Manifests per Age Pool (All marked DEMO_PILOT_ONLY)
    this.examQuestions = {
      GRADE_1_3: [
        { id: 'g13_e1', primaryCompetency: 'NL1', skill: 'Số & Dữ liệu', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Hình nào dưới đây biểu diễn đúng số 15 khi ghép 1 bó 10 que tính và 5 que tính rời?', options: ['A. 1 bó 10 & 5 que rời', 'B. 2 bó 10', 'C. 5 bó 10', 'D. 1 que rời'], correctAnswer: 0 },
        { id: 'g13_e2', primaryCompetency: 'NL2', skill: 'Ngôn ngữ & Truyền thông', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Từ nào dùng đúng để miêu tả một hành động thể hiện tình bạn tốt?', options: ['A. Giúp đỡ bạn', 'B. Giành đồ chơi', 'C. Trêu chọc bạn', 'D. Bỏ mặc bạn'], correctAnswer: 0 },
        { id: 'g13_e3', primaryCompetency: 'NL3', skill: 'Khoa học & Tự nhiên', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Khi thấy rác rơi trên sân trường, em nên làm gì?', options: ['A. Nhặt bỏ vào thùng rác', 'B. Bỏ đi chỗ khác', 'C. Đá rác đi', 'D. Đổ thêm rác'], correctAnswer: 0 },
        { id: 'g13_e4', primaryCompetency: 'NL4', skill: 'Giao tiếp & Thuyết phục', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Khi bạn đưa ý kiến khác em khi thảo luận nhóm, em nên làm gì?', options: ['A. Lắng nghe bạn nói', 'B. Cãi nhau với bạn', 'C. Quát bạn', 'D. Khóc lóc'], correctAnswer: 0 },
        { id: 'g13_e5', primaryCompetency: 'NL5', skill: 'Sáng tạo & Thiết kế', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Số tiếp theo trong dãy số 2, 4, 6, 8, ... là số nào?', options: ['A. 9', 'B. 10', 'C. 11', 'D. 12'], correctAnswer: 1 }
      ],
      GRADE_4_5: [
        { id: 'g45_e1', primaryCompetency: 'NL1', skill: 'Lập kế hoạch làm việc nhóm', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Để chuẩn bị bài thuyết trình nhóm hiệu quả, bước đầu tiên quan trọng nhất là gì?', options: ['A. Phân công nhiệm vụ rõ ràng', 'B. Tranh cãi chọn màu phông', 'C. Mặc kệ một bạn làm hết', 'D. Bỏ cuộc'], correctAnswer: 0 },
        { id: 'g45_e2', primaryCompetency: 'NL4', skill: 'Giao tiếp & Thuyết phục', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Trong tình huống làm việc nhóm có sự bất đồng ý kiến, em nên xử lý thế nào?', options: ['A. Lắng nghe & mời cùng so sánh giải pháp', 'B. Quát bạn', 'C. Bảo ý bạn dở tệ', 'D. Bỏ về nhà'], correctAnswer: 0 },
        { id: 'g45_e3', primaryCompetency: 'NL1', skill: 'Phân tích dữ liệu số', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Dữ liệu nào sau đây thể hiện thông tin số liệu chính xác?', options: ['A. 85% học sinh đúng', 'B. Nhiều bạn đúng', 'C. Rất ít bạn đúng', 'D. Không biết'], correctAnswer: 0 },
        { id: 'g45_e4', primaryCompetency: 'NL3', skill: 'Khoa học & Môi trường', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Hành động nào giúp tiết kiệm năng lượng và bảo vệ môi trường hằng ngày?', options: ['A. Tắt đèn khi ra khỏi phòng', 'B. Bật quạt cả ngày', 'C. Xả nước lãng phí', 'D. Vứt rác lung tung'], correctAnswer: 0 },
        { id: 'g45_e5', primaryCompetency: 'NL6', skill: 'Quản lý thời gian thi', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Nếu thời gian làm bài còn 5 phút và còn 2 câu khó, em nên làm gì?', options: ['A. Ưu tiên câu em có khả năng làm đúng cao nhất', 'B. Bỏ bài ngồi chơi', 'C. Hoảng loạn', 'D. Nộp bài ngay'], correctAnswer: 0 }
      ]
    };

    // 3 Skill Boost Questions (All marked DEMO_PILOT_ONLY)
    this.boostQuestions = [
      { id: 'sb_1', primaryCompetency: 'NL4', skill: 'Giao tiếp & Thuyết phục', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Em muốn đề xuất ý tưởng giữ gìn vệ sinh lớp học với các bạn, em sẽ chọn cách nào?', options: ['A. Nêu lý do & truyền cảm hứng cùng tham gia', 'B. Ép buộc bạn làm', 'C. Mặc kệ', 'D. Báo cô phạt bạn'], correctAnswer: 0, explanation: 'Năng lực Giao tiếp & Thuyết phục giúp tạo sự đồng thuận tích cực!' },
      { id: 'sb_2', primaryCompetency: 'NL6', skill: 'Thích ứng & Tự chủ', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Khi gặp một dạng bài mới chưa từng học, em nên phản ứng thế nào?', options: ['A. Tự tin thử nghiệm nhiều cách giải', 'B. Sợ hãi bỏ cuộc', 'C. Chép bài bạn', 'D. Giận dữ'], correctAnswer: 0, explanation: 'Năng lực Thích ứng & Tự chủ giúp em chủ động học hỏi!' },
      { id: 'sb_3', primaryCompetency: 'NL7', skill: 'Hợp tác & Toàn cầu', status: 'DEMO_PILOT_ONLY', reviewer: 'NVS Academic Board', stem: 'Làm thế nào để phối hợp ăn ý với bạn học đến từ một địa phương khác?', options: ['A. Tôn trọng sự khác biệt & chủ động chia sẻ', 'B. Xa lánh', 'C. Trêu chọc giọng nói', 'D. Không nói chuyện'], correctAnswer: 0, explanation: 'Năng lực Hợp tác & Toàn cầu giúp em gắn kết bạn bè!' }
    ];

    this.currentExamIdx = 0;
    this.currentBoostIdx = 0;
    this.boostFeedback = null;
  }

  /**
   * Hard Item Safety Guard: Ensures no SECURE_ACTIVE or unapproved items load in Student Mode
   */
  assertPilotItemSafety(item) {
    if (!item) return;
    const allowed = ['DEMO_PILOT_ONLY', 'READY_FOR_PILOT'];
    if (!allowed.includes(item.status)) {
      throw new Error(`PILOT_ITEM_SAFETY_VIOLATION: Item ${item.id} has unapproved status '${item.status}'. SECURE_ACTIVE items are forbidden in Student Mode.`);
    }
  }

  init() {
    this.loadFromStorage();
    window.studentController = this;
    window.DEMO_SHOWCASE = false;
    this.renderCurrentStep();
    console.log('🚀 [StudentPilot] Student Controller initialized successfully.');
  }

  loadFromStorage() {
    try {
      if (typeof sessionStorage !== 'undefined') {
        const raw = sessionStorage.getItem(this.storageKey);
        if (raw) {
          const parsed = JSON.parse(raw);
          this.pilotState = { ...this.pilotState, ...parsed };
        }
      }
    } catch (e) {
      console.warn('Could not read student pilot storage:', e);
    }
  }

  saveToStorage() {
    try {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem(this.storageKey, JSON.stringify(this.pilotState));
      }
    } catch (e) {
      console.warn('Could not write student pilot storage:', e);
    }
  }

  logEvent(eventName, payload = {}) {
    const evt = {
      event: eventName,
      sessionId: this.pilotState.sessionId,
      ageGroup: this.pilotState.ageGroup,
      timestamp: new Date().toISOString(),
      ...payload
    };
    this.pilotState.events.push(evt);
    this.saveToStorage();

    if (this.telemetryRepo) {
      this.telemetryRepo.logEvent(evt);
    }
  }

  startPilot(ageGroupKey) {
    this.pilotState.ageGroup = ageGroupKey;
    this.logEvent('pilot_started', { ageGroupKey });
    this.currentStepIndex = 1; // S1 Home
    this.saveToStorage();
    this.renderCurrentStep();
  }

  nextStep() {
    if (this.currentStepIndex < 9) {
      this.currentStepIndex++;
      this.logStepEvent();
      this.renderCurrentStep();
    }
  }

  prevStep() {
    if (this.currentStepIndex > 1) {
      this.currentStepIndex--;
      this.renderCurrentStep();
    }
  }

  logStepEvent() {
    const stepNames = ['welcome', 'home', 'champ_home', 'exam_question', 'practice_result', 'skill_boost', 'reward', 'journey', 'feedback', 'thank_you'];
    const screenName = stepNames[this.currentStepIndex] || 'unknown';
    this.logEvent('screen_viewed', { screenName, stepIndex: this.currentStepIndex });

    const stepEvents = {
      1: 'championship_opened',
      3: 'short_exam_started',
      4: 'practice_result_seen',
      5: 'skill_boost_started',
      6: 'skill_boost_completed',
      7: 'journey_seen'
    };
    if (stepEvents[this.currentStepIndex]) {
      this.logEvent(stepEvents[this.currentStepIndex]);
    }
  }

  answerExamQuestion(questionId, optionIdx) {
    const pool = this.examQuestions[this.pilotState.ageGroup] || this.examQuestions.GRADE_4_5;
    const q = pool[this.currentExamIdx] || pool[0];
    this.assertPilotItemSafety(q);

    this.pilotState.examAnswers[questionId] = optionIdx;

    if (this.currentExamIdx < pool.length - 1) {
      this.currentExamIdx++;
      this.renderCurrentStep();
    } else {
      // Complete Short Exam
      let correct = 0;
      pool.forEach(item => {
        this.assertPilotItemSafety(item);
        if (this.pilotState.examAnswers[item.id] === item.correctAnswer) correct++;
      });
      this.pilotState.examScore = {
        score: Math.round((correct / pool.length) * 100),
        correctCount: correct,
        totalCount: pool.length
      };
      this.logEvent('short_exam_completed', this.pilotState.examScore);
      this.currentStepIndex = 4; // S4 Practice Result
      this.saveToStorage();
      this.renderCurrentStep();
    }
  }

  answerBoostQuestion(questionId, optionIdx) {
    const q = this.boostQuestions[this.currentBoostIdx];
    this.assertPilotItemSafety(q);

    this.pilotState.boostAnswers[questionId] = optionIdx;
    const isCorrect = optionIdx === q.correctAnswer;
    if (isCorrect) {
      this.pilotState.boostCorrectCount = (this.pilotState.boostCorrectCount ?? 0) + 1;
    }
    this.boostFeedback = { isCorrect };
    this.renderCurrentStep();
  }

  advanceBoostQuestion() {
    this.boostFeedback = null;
    if (this.currentBoostIdx < this.boostQuestions.length - 1) {
      this.currentBoostIdx++;
      this.renderCurrentStep();
    } else {
      // Skill Boost Complete: Dynamic XP calculation (correctCount * 6 XP, max 18 XP)
      const correctCount = this.pilotState.boostCorrectCount ?? 0;
      const earnedXP = correctCount * 6;
      this.pilotState.boostXpEarned = earnedXP;
      this.pilotState.xp = (this.pilotState.xp ?? 0) + earnedXP;
      this.pilotState.stars = (this.pilotState.stars ?? 0) + 10;
      this.logEvent('skill_boost_completed', { correctCount, xpEarned: earnedXP, starsEarned: 10 });
      this.currentStepIndex = 6; // S6 Reward
      this.saveToStorage();
      this.renderCurrentStep();
    }
  }

  setFeedbackRating(val) {
    this.pilotState.feedback.q1 = val;
    this.saveToStorage();
    this.renderCurrentStep();
  }

  setFavoritePart(partStr) {
    this.pilotState.feedback.q2 = partStr;
    this.saveToStorage();
    this.renderCurrentStep();
  }

  setReturnIntent(intentStr) {
    this.pilotState.feedback.q3 = intentStr;
    this.saveToStorage();
    this.renderCurrentStep();
  }

  setSuggestion(textStr) {
    // Truncate to max 200 chars
    this.pilotState.feedback.suggestion = (textStr || '').substring(0, 200);
    this.saveToStorage();
  }

  submitFeedback() {
    this.logEvent('feedback_submitted', this.pilotState.feedback);
    this.logEvent('pilot_completed', { sessionId: this.pilotState.sessionId });
    this.currentStepIndex = 9; // S9 Thank You
    this.saveToStorage();
    this.renderCurrentStep();
  }

  restartPilot() {
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem(this.storageKey);
    }
    this.pilotState = {
      sessionId: 'pilot_' + Math.random().toString(36).substring(2, 9),
      ageGroup: 'GRADE_4_5',
      xp: 0,
      stars: 0,
      streak: 1,
      examAnswers: {},
      examScore: null,
      boostAnswers: {},
      boostCorrectCount: 0,
      boostXpEarned: 0,
      feedback: { q1: 5, q2: 'Coach Nova', q3: 'Có!', suggestion: '' },
      events: []
    };
    this.currentStepIndex = 0;
    this.currentExamIdx = 0;
    this.currentBoostIdx = 0;
    this.boostFeedback = null;
    this.renderCurrentStep();
  }

  renderCurrentStep() {
    const container = document.getElementById('app-view-container');
    if (!container) return;

    window.DEMO_SHOWCASE = false;
    this.logStepEvent();
    let html = '';

    switch (this.currentStepIndex) {
      case 0:
        html = DemoStudentViews.renderWelcome();
        break;

      case 1:
        html = DemoStudentViews.renderHome(this.pilotState);
        break;

      case 2:
        html = DemoStudentViews.renderChampionshipHome();
        break;

      case 3:
        const pool = this.examQuestions[this.pilotState.ageGroup] || this.examQuestions.GRADE_4_5;
        const curQ = pool[this.currentExamIdx] || pool[0];
        this.assertPilotItemSafety(curQ);
        html = DemoStudentViews.renderExamQuestion(curQ, this.currentExamIdx, pool.length);
        break;

      case 4:
        html = DemoStudentViews.renderPracticeResult(this.pilotState.examScore || { score: 80, correctCount: 4, totalCount: 5 });
        break;

      case 5:
        const boostQ = this.boostQuestions[this.currentBoostIdx];
        this.assertPilotItemSafety(boostQ);
        html = DemoStudentViews.renderSkillBoostQuestion(boostQ, this.currentBoostIdx, this.boostQuestions.length, this.boostFeedback);
        break;

      case 6:
        html = DemoStudentViews.renderRewardMoment(this.pilotState);
        break;

      case 7:
        html = DemoStudentViews.renderStudentJourney();
        break;

      case 8:
        html = DemoStudentViews.renderStudentFeedback(this.pilotState.feedback);
        break;

      case 9:
        html = DemoStudentViews.renderThankYou();
        break;

      default:
        html = DemoStudentViews.renderWelcome();
    }

    container.innerHTML = html;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { DemoStudentController };
} else if (typeof window !== 'undefined') {
  window.DemoStudentController = DemoStudentController;
}
