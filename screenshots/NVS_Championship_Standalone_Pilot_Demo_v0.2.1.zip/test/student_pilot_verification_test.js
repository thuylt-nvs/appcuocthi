/* ==========================================================================
   NovaStars × NVS Championship — Student Pilot Verification Suite
   v0.2.1 Complete Student Acceptance Matrix (17 Automated Tests)
   ========================================================================== */

class StudentPilotVerificationSuite {
  constructor() {
    this.results = [];
  }

  assert(condition, message) {
    if (!condition) {
      throw new Error(`STUDENT_PILOT_VERIFICATION_FAILED: ${message}`);
    }
  }

  test(name, fn) {
    try {
      fn();
      this.results.push({ name, passed: true });
      console.log(`✅ [Student Pilot Test PASSED] ${name}`);
    } catch (err) {
      this.results.push({ name, passed: false, error: err.message });
      console.log(`❌ [Student Pilot Test FAILED] ${name}: ${err.message}`);
    }
  }

  runAll() {
    console.log('\n===================================================================');
    console.log('🚀 RUNNING STUDENT PILOT ACCEPTANCE MATRIX (17 TESTS)');
    console.log('===================================================================\n');

    // 1. Presenter Control Absence in Student Mode
    this.test('1. Student Mode never renders Presenter controls', () => {
      window.DEMO_SHOWCASE = false;
      const student = new DemoStudentController();
      student.init();
      const isDemoActive = window.DEMO_SHOWCASE === true;
      this.assert(isDemoActive === false, 'Presenter panel must not activate in Student Mode');
    });

    // 2. Presenter Control Presence in Team Mode
    this.test('2. Team Mode renders Presenter controls', () => {
      window.DEMO_SHOWCASE = true;
      const showcase = new DemoShowcaseController();
      showcase.init();
      const isDemoActive = window.DEMO_SHOWCASE === true;
      this.assert(isDemoActive === true, 'Team Mode must enable DEMO_SHOWCASE flag');
    });

    // 3. Independent Sandbox State
    this.test('3. Student and Team sandbox state cannot overwrite one another', () => {
      if (typeof sessionStorage !== 'undefined') {
        sessionStorage.setItem('novastars_demo_showcase_v1', JSON.stringify({ team: 'val' }));
        sessionStorage.setItem('novastars_student_pilot_v1', JSON.stringify({ student: 'val' }));

        const student = new DemoStudentController();
        student.init();
        student.startPilot('GRADE_4_5');

        const teamVal = JSON.parse(sessionStorage.getItem('novastars_demo_showcase_v1'));
        this.assert(teamVal.team === 'val', 'Team sandbox state was overwritten by Student Mode');
      }
    });

    // 4. Production Storage Isolation
    this.test('4. Production LocalStorage remains byte-for-byte unchanged', () => {
      const prodKeys = ['novastars_player_state_v1', 'novastars_user_settings', 'novastars_app_cache'];
      const initialSnapshots = {};

      if (typeof localStorage !== 'undefined') {
        prodKeys.forEach(k => {
          localStorage.setItem(k, JSON.stringify({ key: k, value: `prod_val_${k}` }));
          initialSnapshots[k] = localStorage.getItem(k);
        });
      }

      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_1_3');
      student.currentStepIndex = 3;
      for (let i = 0; i < 5; i++) {
        student.answerExamQuestion(`g13_e${i+1}`, 0);
      }
      student.currentStepIndex = 5;
      for (let i = 0; i < 3; i++) {
        student.answerBoostQuestion(`sb_${i+1}`, 0);
        student.advanceBoostQuestion();
      }

      if (typeof localStorage !== 'undefined') {
        prodKeys.forEach(k => {
          const afterVal = localStorage.getItem(k);
          this.assert(afterVal === initialSnapshots[k], `Production key ${k} was mutated during Student Pilot execution!`);
        });
      }
    });

    // 5 & 6. Age Group Question Pools
    this.test('5 & 6. Grade 1–3 and Grade 4–5 receive correct 5-question short pools', () => {
      const student = new DemoStudentController();
      const poolG13 = student.examQuestions['GRADE_1_3'];
      const poolG45 = student.examQuestions['GRADE_4_5'];

      this.assert(poolG13.length === 5, 'Grade 1–3 exam pool must have 5 questions');
      this.assert(poolG45.length === 5, 'Grade 4–5 exam pool must have 5 questions');
    });

    // 7. Short Exam Completion
    this.test('7. Short Exam completes after exactly 5 questions', () => {
      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_4_5');
      student.currentStepIndex = 3; // Exam Question view

      const pool = student.examQuestions['GRADE_4_5'];
      for (let i = 0; i < 4; i++) {
        student.answerExamQuestion(pool[i].id, 0);
        this.assert(student.currentStepIndex === 3, 'Must remain on exam question view until final answer');
      }
      student.answerExamQuestion(pool[4].id, 0);
      this.assert(student.currentStepIndex === 4, 'Must transition to Practice Result (step 4) after 5th answer');
    });

    // 8. Skill Boost Completion
    this.test('8. Skill Boost completes after exactly 3 questions', () => {
      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_4_5');
      student.currentStepIndex = 5; // Boost step

      for (let i = 0; i < 3; i++) {
        student.answerBoostQuestion(`sb_${i+1}`, 0);
        student.advanceBoostQuestion();
      }
      this.assert(student.currentStepIndex === 6, 'Must transition to Reward view (step 6) after 3rd boost question');
    });

    // 9. Feedback Persistence & Restart
    this.test('9. Student feedback persists & Restart resets Student sandbox deterministically', () => {
      const student = new DemoStudentController();
      student.init();
      student.setFeedbackRating(4);
      student.setFavoritePart('Coach Nova');
      this.assert(student.pilotState.feedback.q1 === 4, 'Feedback rating must persist');
      this.assert(student.pilotState.feedback.q2 === 'Coach Nova', 'Favorite part must persist');

      student.restartPilot();
      this.assert(student.currentStepIndex === 0, 'Restart must reset step index to 0');
      this.assert(student.pilotState.feedback.q1 === 5, 'Restart must reset feedback to default');
    });

    // 10. No PII Field
    this.test('10. No PII field exists in Student pilot state', () => {
      const student = new DemoStudentController();
      const keys = Object.keys(student.pilotState);
      const piiFields = ['name', 'fullName', 'school', 'email', 'phone', 'dob'];
      piiFields.forEach(f => {
        this.assert(!keys.includes(f), `PII field ${f} must not exist in Student pilot state`);
      });
    });

    // 11. Dynamic Boost Reward Calculation (v0.2.1 Patch)
    this.test('11. Dynamic Boost XP reward is calculated from actual responses (max 18 XP)', () => {
      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_4_5');
      student.currentStepIndex = 5;

      // Answer 2 correct out of 3
      student.answerBoostQuestion('sb_1', 0); // Correct (+6)
      student.advanceBoostQuestion();
      student.answerBoostQuestion('sb_2', 1); // Incorrect (+0)
      student.advanceBoostQuestion();
      student.answerBoostQuestion('sb_3', 0); // Correct (+6)
      student.advanceBoostQuestion();

      this.assert(student.pilotState.boostCorrectCount === 2, 'Boost correct count must be 2');
      this.assert(student.pilotState.boostXpEarned === 12, 'Boost XP earned must be 12 (2 * 6)');
    });

    // 12. Pilot Item Safety Guard
    this.test('12. Pilot item safety guard rejects SECURE_ACTIVE items', () => {
      const student = new DemoStudentController();
      let caught = false;
      try {
        student.assertPilotItemSafety({ id: 'secure_1', status: 'SECURE_ACTIVE' });
      } catch (err) {
        caught = true;
        this.assert(err.message.includes('PILOT_ITEM_SAFETY_VIOLATION'), 'Error message must specify safety violation');
      }
      this.assert(caught === true, 'Safety guard must throw error when encountering SECURE_ACTIVE status');
    });

    // 13. Telemetry Repository Network Failure Tolerance
    this.test('13. Telemetry Repository handles network failure gracefully without throwing', async () => {
      const repo = new PilotTelemetryRepository();
      let threw = false;
      try {
        await repo.logEvent({ event: 'test_event', sessionId: 'test_sess' });
      } catch (err) {
        threw = true;
      }
      this.assert(threw === false, 'logEvent must not throw exception even if network fetch fails');
    });

    // 14. Suggestion Max Length 200
    this.test('14. Free-text suggestion is truncated to max 200 characters', () => {
      const student = new DemoStudentController();
      student.init();
      const longText = 'A'.repeat(250);
      student.setSuggestion(longText);
      this.assert(student.pilotState.feedback.suggestion.length === 200, 'Suggestion length must be capped at 200 characters');
    });

    // 15. Non-Diagnostic Result Framing Notice
    this.test('15. Practice Result contains non-diagnostic framing notice', () => {
      const html = DemoStudentViews.renderPracticeResult({ score: 80, correctCount: 4, totalCount: 5 });
      this.assert(html.includes('Dựa trên bài trải nghiệm ngắn này...'), 'Result view must contain non-diagnostic disclaimer notice');
    });

    // 16. Data Minimization Notice in Feedback View
    this.test('16. Feedback view contains data minimization warning', () => {
      const html = DemoStudentViews.renderStudentFeedback({ q1: 5, q2: 'Coach Nova', q3: 'Có!', suggestion: '' });
      this.assert(html.includes('Không cần ghi tên, trường, số điện thoại'), 'Feedback view must inform students not to provide PII');
    });

    // 17. Usability Telemetry Funnel Logging
    this.test('17. Usability telemetry tracks screen_viewed and pilot_completed events', () => {
      const student = new DemoStudentController();
      student.init();
      student.startPilot('GRADE_4_5');
      student.submitFeedback();

      const events = student.pilotState.events.map(e => e.event);
      this.assert(events.includes('pilot_started'), 'Events must include pilot_started');
      this.assert(events.includes('screen_viewed'), 'Events must include screen_viewed');
      this.assert(events.includes('feedback_submitted'), 'Events must include feedback_submitted');
      this.assert(events.includes('pilot_completed'), 'Events must include pilot_completed');
    });

    const passed = this.results.filter(r => r.passed).length;
    const total = this.results.length;

    console.log('\n===================================================================');
    console.log(`📊 STUDENT PILOT VERIFICATION RESULTS: ${passed}/${total} PASSED`);
    console.log('===================================================================\n');

    return { total, passed, failed: total - passed, results: this.results };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { StudentPilotVerificationSuite };
} else if (typeof window !== 'undefined') {
  window.StudentPilotVerificationSuite = StudentPilotVerificationSuite;
}
